/**
 * $Id: mxOrthogonalModel.java,v 1.1 2009-11-25 12:36:37 david Exp $
 * Copyright (c) 2008-2009, JGraph Ltd
 */
package com.mxgraph.layout.orthogonal.model;

import com.mxgraph.view.mxGraph;

/**
 * A custom graph model 
 */
public class mxOrthogonalModel
{
   public mxOrthogonalModel(mxGraph graph)
   {
      // 
   }
}
