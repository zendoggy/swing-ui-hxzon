/**
 * The package contains all kinds of comparators for JIDE Common Layer.
 */
package com.jidesoft.comparator;